package org.jbpm.test.lifecycle.test;

import org.subethamail.wiser.Wiser;

public class Test {

	public static void main(String[] args) {
		System.out.println(Wiser.class);
	}

}
